Shoguns Clan 
By Chris Hansen, all rights reserved, 2004.

This font is based on some of those samurai B-movie flicks from the 80's.

This font is a freeware, any sort of Commercial, use
requires written permission from the author and copyright holder, 
Chris Hansen.

Crizcrack_666@hotmail.com

www.geocities.com/crizcrack666